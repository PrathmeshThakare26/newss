import React from 'react'
import NewsFeed from './NewsFeed'
function App() {
  return (
<>
<NewsFeed/>
</>
  )
}

export default App
